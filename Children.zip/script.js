function getResponsiveBreakpoints(options = {}) {
    const BREAKPOINTS = {
        MOBILE: [320, 480],
        TABLET: [481, 768],
        LAPTOP: [769, 1024],
        DESKTOP: [1025, 1200],
        TV: [1201, Infinity]
    }

    // Dodajemo objekat sa podacima o bojama i njihovim kontrastima
    const COLORS = {
    'Pastel Green': { backgroundColor: '#A6E3A4', textColor: '#222' },
    'Pastel Purple': { backgroundColor: '#D7A9E3', textColor: '#222' },
    'Pastel Peach': { backgroundColor: '#FFC9B2', textColor: '#222' },
    'Pastel Blue': { backgroundColor: '#9ACBDF', textColor: '#222' },
    'Pastel Yellow': { backgroundColor: '#FFF699', textColor: '#222' },
    'Pastel Pink': { backgroundColor: '#FFAAC6', textColor: '#222' },
    'Pastel Brown': { backgroundColor: '#D7A16E', textColor: '#FFFFFF' },
    'Pastel Red': { backgroundColor: '#FF6B6B', textColor: '#FFFFFF' },
    'Pastel Violet': { backgroundColor: '#9E6FD9', textColor: '#FFFFFF' },
    'Pastel Gray': { backgroundColor: '#B0B0B0', textColor: '#FFFFFF' }
};


    // Odabir boje na osnovu opcije ili podrazumevane boje
    const selectedColor = options.backgroundColor || 'Mint Green Paste';

    function getDeviceType() {
        const width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        let deviceType = '';

        if (width >= BREAKPOINTS.MOBILE[0] && width <= BREAKPOINTS.MOBILE[1]) {
            deviceType = 'Mobile Devices';
        } else if (width >= BREAKPOINTS.TABLET[0] && width <= BREAKPOINTS.TABLET[1]) {
            deviceType = 'iPads and Tablets';
        } else if (width >= BREAKPOINTS.LAPTOP[0] && width <= BREAKPOINTS.LAPTOP[1]) {
            deviceType = 'Laptops and small screens';
        } else if (width >= BREAKPOINTS.DESKTOP[0] && width <= BREAKPOINTS.DESKTOP[1]) {
            deviceType = 'Large screens and Desktops';
        } else if (width >= BREAKPOINTS.TV[0]) {
            deviceType = 'TV and Extra Large Screens';
        }

        return deviceType;
    }

    const viewportDimensions = document.createElement('div');
    viewportDimensions.id = 'viewport-dimensions';

    // Povežemo odabranu boju sa kontrastima
    const selectedColorData = COLORS[selectedColor];

    const style = document.createElement('style');
    style.textContent = `
      #viewport-dimensions {
        position: fixed;
        top: 0.25rem;
        right: 0.25rem;
        padding: 1rem 1.5rem;
        font-family: Verdana;
        font-size: ${options.fontSize || '0.85rem'};
        z-index: 9999;
        background-color: ${selectedColorData.backgroundColor};
        color: ${selectedColorData.textColor};
        font-weight: bold;
        border-radius: 10px;
        box-shadow: 0 12px 20px -10px rgba(0,0,0,0.28), 
        0 4px 20px 0 rgba(0,0,0,0.12), 
        0 7px 8px -5px rgba(0,0,0,0.2);
      }
    `;

    document.head.appendChild(style);
    document.body.appendChild(viewportDimensions);

    function showViewportDimensions() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        const deviceType = getDeviceType();

        const message = `${deviceType} (${width} x ${height})`;
        viewportDimensions.textContent = message;
    }

    window.addEventListener('resize', showViewportDimensions);

    showViewportDimensions();
}
function addDebugButton(backgroundColorStyle, textColorStyle) {
    const debugContainer = document.createElement('div');
    debugContainer.id = 'css-debug';
    document.body.appendChild(debugContainer);

    debugContainer.innerHTML = 'Debug CSS';
    debugContainer.style.cssText = `
    position: fixed;
    bottom: 1rem;
    right: 1rem;
    padding: 0.5rem 1rem;
    background-color: 'green'};
    border: 1px solid #fff;
    color: ${textColorStyle || '#fff'}; /* Koristimo unetu boju teksta ili podrazumevanu belu ako nije uneta boja */
    border-radius: 5px;
    cursor: pointer;
    z-index: 9999;
    font-family:Verdana;
    font-size:0.85rem;
`;

    let isDebugMode = false;

    debugContainer.addEventListener('click', () => {
        isDebugMode = !isDebugMode;

        if (isDebugMode) {
            const style = document.createElement('style');
            style.id = 'debug-style';
            style.textContent = '*:not(#css-debug):not(#viewport-dimensions) { background-color:rgb(0 100 0 / 0.1) !important; border:1px solid #000;margin:10px;}';
            document.head.appendChild(style);
            debugContainer.style.backgroundColor = 'red';
        } else {
            const style = document.getElementById('debug-style');
            if (style) {
                style.parentNode.removeChild(style);
            }
            debugContainer.style.backgroundColor = backgroundColorStyle || 'green';
            debugContainer.style.color = textColorStyle || '#fff'; /* Vratimo boju teksta na unetu ili podrazumevanu boju */
        }
    });
}
